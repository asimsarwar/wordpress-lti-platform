// $('.recall-progress-bar').circleProgress({
//   value: 0.35,
//   size: 80.0,
//   fill: {
//     gradient: ['#CA2738'], // or color: '#3aeabb', or image: 'http://i.imgur.com/pT0i89v.png'
//   },
// });

// $('.pa-progress-bar').circleProgress({
//   value: 0.35,
//   size: 80.0,
//   fill: {
//     gradient: ['#1FA5D4'], // or color: '#3aeabb', or image: 'http://i.imgur.com/pT0i89v.png'
//   },
// });

// $('.pb-progress-bar').circleProgress({
//   value: 0.35,
//   size: 80.0,
//   fill: {
//     gradient: ['#1FA5D4'], // or color: '#3aeabb', or image: 'http://i.imgur.com/pT0i89v.png'
//   },
// });
// $('.apply-progress-bar').circleProgress({
//   value: 0.35,
//   size: 80.0,
//   fill: {
//     gradient: ['#9FC33B'], // or color: '#3aeabb', or image: 'http://i.imgur.com/pT0i89v.png'
//   },
// });
